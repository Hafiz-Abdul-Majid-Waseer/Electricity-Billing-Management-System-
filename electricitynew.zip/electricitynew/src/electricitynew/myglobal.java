
package electricitynew;

public class myglobal {
    static String uname;
    static int newread;
    
}
