
package electricitynew;

public class myglobalclass {
    static String uname;



 
    
}
