package electricitynew;

import java.sql.Connection;


public interface myvariables {
 
    String path="jdbc:mysql://localhost/";
    String place="conectionform";
    String username="root";
    String password=""; 
}
